import {
  GradientText,
  HeroAvatar,
  Section,
} from 'astro-boilerplate-components';
import GitHubButton from 'react-github-btn';

const Hero = () => (
  <Section>
    <HeroAvatar
      title={
        <>
          i am <GradientText>Catdrout</GradientText>
        </>
      }
      description={
        <>
          I have mastered{' '}
          <a className="text-blue-400 hover:underline" href="/">
            C#, Python HTML, CSS, JS and Ruby
          </a>{' '}
          My choice of operating system is{' '}
          <a className="text-green-400 hover:underline" href="/">
            Arch Linux
          </a>{' '}
        </>
      }
      avatar={
        <img
          src="/assets/images/avatar-modified.png"
          alt="Avatar image"
          loading="lazy"
        />
      }
      socialButtons={
        <>
          <GitHubButton
            href="https://github.com/catdroutcode"
            aria-label="Follow @catdroutcode on GitHub"
          >
            Follow @catdroutcode
          </GitHubButton>
        </>
      }
    />
  </Section>
);

export { Hero };
