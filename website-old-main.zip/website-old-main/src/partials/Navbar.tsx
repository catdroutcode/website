import { Section } from 'astro-boilerplate-components';

const Navbar = () => <Section></Section>;

export { Navbar };
