import {
  ColorTags,
  GradientText,
  Project,
  Section,
  Tags,
} from 'astro-boilerplate-components';

const ProjectList = () => (
  <Section
    title={
      <>
        Recent <GradientText>Projects</GradientText>
      </>
    }
  >
    <div className="flex flex-col gap-6">
      <Project
        name="None"
        description=""
        link="/"
        img={{
          src: 'https://images.unsplash.com/photo-1516259762381-22954d7d3ad2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1189&q=80',
          alt: '',
        }}
        category={
          <>
            <Tags color={ColorTags.FUCHSIA}>coding my next project</Tags>
          </>
        }
      />
    </div>
  </Section>
);

export { ProjectList };
