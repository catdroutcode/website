export const AppConfig = {
  site_name: 'catdrout.xyz',
  title: 'Catdrout inc',
  description: ' a personal website',
  author: 'catdrout',
  locale_region: 'sv-SE',
  locale: 'en',
};
